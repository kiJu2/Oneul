package com.example.oneul;

public class Diary {

    private int emo; // 감정 코드
    private String date; // 일기 날짜
    private String contents; // 일기 내용

    public int getEmo() {
        return emo;
    }

    public void setEmo(int emo) {
        this.emo = emo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }
}

